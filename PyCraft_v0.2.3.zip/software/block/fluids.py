

from ids import BlockID


TICK_INTERVAL = 0.05


_NEIGHBORS = [

    (0, -1, 0),                                              

    (1, 0, 0), (-1, 0, 0),

    (0, 0, 1), (0, 0, -1),

]


_FLOWING_TO_STILL = {

    BlockID.WATER: BlockID.STILL_WATER,

    BlockID.LAVA:  BlockID.STILL_LAVA,

}


_WATER_IDS = (BlockID.WATER, BlockID.STILL_WATER)

_LAVA_IDS  = (BlockID.LAVA,  BlockID.STILL_LAVA)

_FLOWING   = frozenset((BlockID.WATER, BlockID.LAVA))


_active: set = set()

_ready: bool = False


def _init(world) -> None:


    global _ready

    sx, sz = world.size_x, world.size_z

    sxz = sx * sz

    for i, b in enumerate(world.blocks):

        if b == BlockID.WATER or b == BlockID.LAVA:

                                                                           
            _active.add((i % sx, i // sxz, (i // sx) % sz))

    _ready = True


def activate(x: int, y: int, z: int) -> None:


    _active.add((x, y, z))


def tick(world) -> list:

    global _ready, _active

    if not _ready:

        _init(world)


    changes  = []

    to_add   = set()

    to_remove = set()


    for (x, y, z) in list(_active):

        block = world.get_block(x, y, z)

        if block not in _FLOWING:

            to_remove.add((x, y, z))

            continue


        spread = False

        for dx, dy, dz in _NEIGHBORS:

            nx, ny, nz = x + dx, y + dy, z + dz

            if not world.in_bounds(nx, ny, nz):

                continue

            nb = world.get_block(nx, ny, nz)


            if nb == BlockID.AIR:

                world.set_block(nx, ny, nz, block)

                changes.append((nx, ny, nz, block))

                to_add.add((nx, ny, nz))

                spread = True

            elif block == BlockID.WATER and nb in _LAVA_IDS:

                world.set_block(nx, ny, nz, BlockID.OBSIDIAN)

                changes.append((nx, ny, nz, BlockID.OBSIDIAN))

                to_remove.add((nx, ny, nz))

            elif block == BlockID.LAVA and nb in _WATER_IDS:

                world.set_block(x, y, z, BlockID.OBSIDIAN)

                changes.append((x, y, z, BlockID.OBSIDIAN))

                to_remove.add((x, y, z))

                spread = False

                break


        if not spread and world.get_block(x, y, z) == block:

            still = _FLOWING_TO_STILL[block]

            world.set_block(x, y, z, still)

            changes.append((x, y, z, still))

            to_remove.add((x, y, z))


    _active -= to_remove

    _active |= to_add

    return changes


def wake_neighbors(world, x: int, y: int, z: int) -> list:


    changes = []

    for dx, dy, dz in _NEIGHBORS + [(0, 1, 0)]:

        nx, ny, nz = x + dx, y + dy, z + dz

        if not world.in_bounds(nx, ny, nz):

            continue

        nb = world.get_block(nx, ny, nz)

        if nb == BlockID.STILL_WATER:

            world.set_block(nx, ny, nz, BlockID.WATER)

            changes.append((nx, ny, nz, BlockID.WATER))

            _active.add((nx, ny, nz))

        elif nb == BlockID.STILL_LAVA:

            world.set_block(nx, ny, nz, BlockID.LAVA)

            changes.append((nx, ny, nz, BlockID.LAVA))

            _active.add((nx, ny, nz))

    return changes

