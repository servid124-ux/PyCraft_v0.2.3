

import socket

from dataclasses import dataclass


from protocolo import PacketID, ProtocolConfig

from buffer import NetWriter, NetReader


STRING_LEN = ProtocolConfig.STRING_LEN

ARRAY_LEN = ProtocolConfig.ARRAY_LEN


class Packet:


    packet_id: int = None


    def write_body(self, w: NetWriter) -> None:

        raise NotImplementedError


    @classmethod

    def read_body(cls, r: NetReader) -> "Packet":

        raise NotImplementedError


    def encode(self) -> bytes:

        w = NetWriter()

        w.write_u8(self.packet_id)

        self.write_body(w)

        return w.getvalue()


    @classmethod

    def decode(cls, sock: socket.socket) -> "Packet":

        r = NetReader(sock)

        return cls.read_body(r)


@dataclass

class Identification(Packet):

    packet_id = PacketID.IDENTIFICATION

    protocol_version: int = 0x07

    username: str = ""

    verification_key: str = ""                                        

    user_type: int = 0x00                                                    


    def write_body(self, w: NetWriter) -> None:

        w.write_u8(self.protocol_version)

        w.write_string(self.username)

        w.write_string(self.verification_key)

        w.write_u8(self.user_type)


    @classmethod

    def read_body(cls, r: NetReader) -> "Identification":

        proto = r.read_u8()

        uname = r.read_string()

        vkey = r.read_string()

        utype = r.read_u8()

        return cls(proto, uname, vkey, utype)


Handshake = Identification


@dataclass

class Ping(Packet):

    packet_id = PacketID.PING


    def write_body(self, w: NetWriter) -> None:

        pass               


    @classmethod

    def read_body(cls, r: NetReader) -> "Ping":

        return cls()


@dataclass

class LevelInitialize(Packet):

    packet_id = PacketID.LEVEL_INITIALIZE


    def write_body(self, w: NetWriter) -> None:

        pass


    @classmethod

    def read_body(cls, r: NetReader) -> "LevelInitialize":

        return cls()


@dataclass

class LevelDataChunk(Packet):

    packet_id = PacketID.LEVEL_DATA_CHUNK

    chunk_length: int = 0                                                   

    chunk_data: bytes = b""                             

    percent_complete: int = 0             


    def write_body(self, w: NetWriter) -> None:

        w.write_u16(self.chunk_length)

        w.write_byte_array(self.chunk_data, ARRAY_LEN)

        w.write_u8(self.percent_complete)


    @classmethod

    def read_body(cls, r: NetReader) -> "LevelDataChunk":

        length = r.read_u16()

        data = r.read_byte_array(ARRAY_LEN)

        percent = r.read_u8()

        return cls(length, data[:length], percent)


@dataclass

class LevelFinalize(Packet):

    packet_id = PacketID.LEVEL_FINALIZE

    size_x: int = 0

    size_y: int = 0

    size_z: int = 0


    def write_body(self, w: NetWriter) -> None:

        w.write_u16(self.size_x)

        w.write_u16(self.size_y)

        w.write_u16(self.size_z)


    @classmethod

    def read_body(cls, r: NetReader) -> "LevelFinalize":

        x = r.read_u16()

        y = r.read_u16()

        z = r.read_u16()

        return cls(x, y, z)


@dataclass

class SetBlockClient(Packet):

    packet_id = PacketID.SET_BLOCK_CLIENT

    x: int = 0

    y: int = 0

    z: int = 0

    mode: int = 0                                    

    block_type: int = 0


    def write_body(self, w: NetWriter) -> None:

        w.write_i16(self.x)

        w.write_i16(self.y)

        w.write_i16(self.z)

        w.write_u8(self.mode)

        w.write_u8(self.block_type)


    @classmethod

    def read_body(cls, r: NetReader) -> "SetBlockClient":

        x = r.read_i16()

        y = r.read_i16()

        z = r.read_i16()

        mode = r.read_u8()

        btype = r.read_u8()

        return cls(x, y, z, mode, btype)


@dataclass

class SetBlockServer(Packet):

    packet_id = PacketID.SET_BLOCK_SERVER

    x: int = 0

    y: int = 0

    z: int = 0

    block_type: int = 0


    def write_body(self, w: NetWriter) -> None:

        w.write_i16(self.x)

        w.write_i16(self.y)

        w.write_i16(self.z)

        w.write_u8(self.block_type)


    @classmethod

    def read_body(cls, r: NetReader) -> "SetBlockServer":

        x = r.read_i16()

        y = r.read_i16()

        z = r.read_i16()

        btype = r.read_u8()

        return cls(x, y, z, btype)


@dataclass

class SpawnPlayer(Packet):

    packet_id = PacketID.SPAWN_PLAYER

    player_id: int = 0                                           

    name: str = ""

    x: float = 0.0                                                         

    y: float = 0.0

    z: float = 0.0

    yaw: int = 0                    

    pitch: int = 0                  


    def write_body(self, w: NetWriter) -> None:

        w.write_i8(self.player_id)

        w.write_string(self.name)

        w.write_fpos(self.x)

        w.write_fpos(self.y)

        w.write_fpos(self.z)

        w.write_u8(self.yaw)

        w.write_u8(self.pitch)


    @classmethod

    def read_body(cls, r: NetReader) -> "SpawnPlayer":

        pid = r.read_i8()

        name = r.read_string()

        x = r.read_fpos()

        y = r.read_fpos()

        z = r.read_fpos()

        yaw = r.read_u8()

        pitch = r.read_u8()

        return cls(pid, name, x, y, z, yaw, pitch)


@dataclass

class PlayerTeleport(Packet):

    packet_id = PacketID.PLAYER_TELEPORT

    player_id: int = 0                                             

    x: float = 0.0

    y: float = 0.0

    z: float = 0.0

    yaw: int = 0

    pitch: int = 0


    def write_body(self, w: NetWriter) -> None:

        w.write_i8(self.player_id)

        w.write_fpos(self.x)

        w.write_fpos(self.y)

        w.write_fpos(self.z)

        w.write_u8(self.yaw)

        w.write_u8(self.pitch)


    @classmethod

    def read_body(cls, r: NetReader) -> "PlayerTeleport":

        pid = r.read_i8()

        x = r.read_fpos()

        y = r.read_fpos()

        z = r.read_fpos()

        yaw = r.read_u8()

        pitch = r.read_u8()

        return cls(pid, x, y, z, yaw, pitch)


@dataclass

class PositionOrientationUpdate(Packet):

    packet_id = PacketID.POSITION_ORIENTATION_UPDATE

    player_id: int = 0

    dx: int = 0                                   

    dy: int = 0

    dz: int = 0

    yaw: int = 0

    pitch: int = 0


    def write_body(self, w: NetWriter) -> None:

        w.write_i8(self.player_id)

        w.write_i8(self.dx)

        w.write_i8(self.dy)

        w.write_i8(self.dz)

        w.write_u8(self.yaw)

        w.write_u8(self.pitch)


    @classmethod

    def read_body(cls, r: NetReader) -> "PositionOrientationUpdate":

        pid = r.read_i8()

        dx = r.read_i8()

        dy = r.read_i8()

        dz = r.read_i8()

        yaw = r.read_u8()

        pitch = r.read_u8()

        return cls(pid, dx, dy, dz, yaw, pitch)


@dataclass

class PositionUpdate(Packet):

    packet_id = PacketID.POSITION_UPDATE

    player_id: int = 0

    dx: int = 0

    dy: int = 0

    dz: int = 0


    def write_body(self, w: NetWriter) -> None:

        w.write_i8(self.player_id)

        w.write_i8(self.dx)

        w.write_i8(self.dy)

        w.write_i8(self.dz)


    @classmethod

    def read_body(cls, r: NetReader) -> "PositionUpdate":

        pid = r.read_i8()

        dx = r.read_i8()

        dy = r.read_i8()

        dz = r.read_i8()

        return cls(pid, dx, dy, dz)


@dataclass

class OrientationUpdate(Packet):

    packet_id = PacketID.ORIENTATION_UPDATE

    player_id: int = 0

    yaw: int = 0

    pitch: int = 0


    def write_body(self, w: NetWriter) -> None:

        w.write_i8(self.player_id)

        w.write_u8(self.yaw)

        w.write_u8(self.pitch)


    @classmethod

    def read_body(cls, r: NetReader) -> "OrientationUpdate":

        pid = r.read_i8()

        yaw = r.read_u8()

        pitch = r.read_u8()

        return cls(pid, yaw, pitch)


@dataclass

class DespawnPlayer(Packet):

    packet_id = PacketID.DESPAWN_PLAYER

    player_id: int = 0


    def write_body(self, w: NetWriter) -> None:

        w.write_i8(self.player_id)


    @classmethod

    def read_body(cls, r: NetReader) -> "DespawnPlayer":

        pid = r.read_i8()

        return cls(pid)


@dataclass

class Message(Packet):

    packet_id = PacketID.MESSAGE

    player_id: int = 0                                                                           

    message: str = ""


    def write_body(self, w: NetWriter) -> None:

        w.write_i8(self.player_id)

        w.write_string(self.message)


    @classmethod

    def read_body(cls, r: NetReader) -> "Message":

        pid = r.read_i8()

        msg = r.read_string()

        return cls(pid, msg)


@dataclass

class DisconnectPlayer(Packet):

    packet_id = PacketID.DISCONNECT_PLAYER

    reason: str = ""


    def write_body(self, w: NetWriter) -> None:

        w.write_string(self.reason)


    @classmethod

    def read_body(cls, r: NetReader) -> "DisconnectPlayer":

        reason = r.read_string()

        return cls(reason)


@dataclass

class UpdateUserType(Packet):

    packet_id = PacketID.UPDATE_USER_TYPE

    user_type: int = 0x00                         


    def write_body(self, w: NetWriter) -> None:

        w.write_u8(self.user_type)


    @classmethod

    def read_body(cls, r: NetReader) -> "UpdateUserType":

        utype = r.read_u8()

        return cls(utype)


PACKET_REGISTRY = {

    PacketID.IDENTIFICATION: Identification,

    PacketID.PING: Ping,

    PacketID.LEVEL_INITIALIZE: LevelInitialize,

    PacketID.LEVEL_DATA_CHUNK: LevelDataChunk,

    PacketID.LEVEL_FINALIZE: LevelFinalize,

    PacketID.SET_BLOCK_CLIENT: SetBlockClient,

    PacketID.SET_BLOCK_SERVER: SetBlockServer,

    PacketID.SPAWN_PLAYER: SpawnPlayer,

    PacketID.PLAYER_TELEPORT: PlayerTeleport,

    PacketID.POSITION_ORIENTATION_UPDATE: PositionOrientationUpdate,

    PacketID.POSITION_UPDATE: PositionUpdate,

    PacketID.ORIENTATION_UPDATE: OrientationUpdate,

    PacketID.DESPAWN_PLAYER: DespawnPlayer,

    PacketID.MESSAGE: Message,

    PacketID.DISCONNECT_PLAYER: DisconnectPlayer,

    PacketID.UPDATE_USER_TYPE: UpdateUserType,

}


def read_packet(sock: socket.socket) -> Packet:


    r = NetReader(sock)

    packet_id = r.read_u8()


    cls = PACKET_REGISTRY.get(packet_id)

    if cls is None:

        raise ValueError(f"Packet ID desconocido: 0x{packet_id:02X}")


    return cls.read_body(r)


def send_packet(sock: socket.socket, packet: Packet) -> None:


    sock.sendall(packet.encode())


if __name__ == "__main__":

    import io


    class FakeSocket:


        def __init__(self, data: bytes):

            self.buf = io.BytesIO(data)


        def recv(self, n):

            return self.buf.read(n)


    tests = [

        Identification(0x07, "Notch", "abc123", 0x00),

        Ping(),

        LevelInitialize(),

        LevelDataChunk(512, b"\x01" * 512, 50),

        LevelFinalize(64, 64, 64),

        SetBlockClient(10, 20, 30, 1, 5),

        SetBlockServer(10, 20, 30, 5),

        SpawnPlayer(-1, "Notch", 8.5, 65.0, 8.5, 0, 0),

        PlayerTeleport(-1, 8.5, 65.0, 8.5, 128, 0),

        PositionOrientationUpdate(0, 1, -1, 0, 10, 20),

        PositionUpdate(0, 1, -1, 0),

        OrientationUpdate(0, 100, 50),

        DespawnPlayer(0),

        Message(0, "hola che crack"),                                                  

        DisconnectPlayer("baneado"),

        UpdateUserType(0x64),

    ]


    print("Corriendo self-test del codec (basado en buffer)...\n")

    for pkt in tests:

        encoded = pkt.encode()

        fsock = FakeSocket(encoded[1:])                                         

        decoded = type(pkt).decode(fsock)

        status = "OK" if decoded == pkt else "FAIL"

        print(f"[{status}] {type(pkt).__name__:30s} ({len(encoded):4d} bytes)")

        if status == "FAIL":

            print(f"       esperado: {pkt}")

            print(f"       obtenido: {decoded}")


    print("\nTodos los packet IDs registrados:", len(PACKET_REGISTRY))


    print("\nDemo: encadenando varios paquetes en un solo buffer (como un stream real):")

    combo = NetWriter()

    for pkt in [Ping(), Message(0, "hola"), Ping()]:

        combo.write_raw(pkt.encode())

    print(f"  3 paquetes combinados -> {len(combo.getvalue())} bytes en un solo buffer")

