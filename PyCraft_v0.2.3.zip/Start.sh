#!/usr/bin/env sh

cd "$(dirname "$0")"

echo ""
echo "  ____        ____            __ _   "
echo " |  _ \ _   _/ ___|_ __ __ _ / _| |_ "
echo " | |_) | | | \___ \ '__/ _\` | |_| __|"
echo " |  __/| |_| |___) | | | (_| |  _| |_ "
echo " |_|    \__, |____/|_|  \__,_|_|  \__|"
echo "         |___/                  v0.2.3 "
echo ""

# Buscar python3 o python (Termux usa 'python')
PYTHON=""
for cmd in python3 python; do
    if command -v "$cmd" > /dev/null 2>&1; then
        PYTHON="$cmd"
        break
    fi
done

if [ -z "$PYTHON" ]; then
    echo "[ERROR] Python no encontrado."
    echo "  En Termux ejecuta: pkg install python"
    exit 1
fi

CRASHES=0
while true; do
    "$PYTHON" software/software_servidor.py
    EXIT_CODE=$?

    if [ $EXIT_CODE -eq 0 ]; then
        echo ""
        echo "[PyCraft] Servidor detenido correctamente."
        break
    fi

    CRASHES=$((CRASHES + 1))
    echo ""
    echo "[PyCraft] Servidor caido (codigo $EXIT_CODE) — reiniciando en 3s... (crash #$CRASHES)"
    sleep 3
done
